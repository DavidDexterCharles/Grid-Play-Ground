A Pen created at CodePen.io. You can find this one at http://codepen.io/ICE-WOLF/pen/WrMvdm.

 Semantic UI includes a tabs plugin that isn't in the documentation. Here's an example of how it works.

Please note you must include the jquery.address script.

Forked from [Justin](http://codepen.io/jwarnes/)'s Pen [Semantic UI - Tabs](http://codepen.io/jwarnes/pen/BvbgF/).